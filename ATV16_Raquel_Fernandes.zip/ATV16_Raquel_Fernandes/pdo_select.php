<?php 
    $endereco = "localhost"; 
    $usuario = "root";
    $senha = "";
    $banco = "empresa";

?>

<div>
    <adress>
        <center>Raquel Fernandes- Estudante- Técnico de Desenvolvimento de Sistemas</center>
    </adress>
</div>